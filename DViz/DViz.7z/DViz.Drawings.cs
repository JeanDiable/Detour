﻿using System;
using System.Collections.Concurrent;
using System.Drawing;
using System.Windows.Forms;
using DetourCore.Debug;

namespace DViz
{
    public class Dummy2
    {
    }


    public partial class DViz
    {

        public class DvizPainter : MapPainter
        {
            private Action<Graphics>[] actions = new Action<Graphics>[1024];
            private int ptr = 0;

            public override void drawLine(Color pen, float width, float x1, float y1, float x2, float y2)
            {
                var dx1 = x1;//st.Item1;
                var dy1 = y1;//st.Item2;
                var dx2 = x2;//end.Item1;
                var dy2 = y2;//end.Item2;
                actions[ptr++]=(g) =>
                {
                    var p = new Pen(pen, width);
                    g.DrawEllipse(p, (float) (instance.mapBox.Width / 2 + dx1 * scale - centerX * scale - 1),
                        (float) (instance.mapBox.Height / 2 - dy1 * scale + centerY * scale - 1), 3, 3);
                    g.DrawEllipse(p, (float)(instance.mapBox.Width / 2 + dx2 * scale - centerX * scale - 1),
                        (float)(instance.mapBox.Height / 2 - dy2 * scale + centerY * scale - 1), 3, 3);
                    g.DrawLine(p,
                        (float)(instance.mapBox.Width / 2 + dx1 * scale - centerX * scale),
                        (float)(instance.mapBox.Height / 2 - dy1 * scale + centerY * scale),
                        (float)(instance.mapBox.Width / 2 + dx2 * scale - centerX * scale),
                        (float)(instance.mapBox.Height / 2 - dy2 * scale + centerY * scale));
                };
            }


            public override void drawDotG(Color pen, float w, float x1, float y1)
            {
                actions[ptr++]=((g) =>
                {
                    g.DrawEllipse(new Pen(pen,w),(float)(instance.mapBox.Width / 2 + x1 * scale - centerX * scale - 2),
                        (float)(instance.mapBox.Height / 2 - y1 * scale + centerY * scale - 2), 5, 5);
                });
            }

            public override void drawText(string str, Color color, float x1, float y1)
            {
                var dx1 = x1;//st.Item1;
                var dy1 = y1;//st.Item2;
                actions[ptr++] = ((g) =>
                {
                    g.DrawString(str, SystemFonts.DefaultFont, new SolidBrush(color),
                        (float) (instance.mapBox.Width / 2 + dx1 * scale - centerX * scale - 1),
                        (float) (instance.mapBox.Height / 2 - dy1 * scale + centerY * scale - 1));
                });
            }

            public override void drawEllipse(Color color, float x1, float y1, float w, float h)
            {
                actions[ptr++]=(g) =>
                {
                    g.DrawEllipse(new Pen(color),instance.mapBox.Width / 2 + (x1 - w / 2) * scale - centerX * scale,
                        instance.mapBox.Height / 2 - (y1 + h / 2) * scale + centerY * scale, w * scale, h * scale);
                };
            }

            public override void clear()
            {
                ptr = 0;
            }
        }

        public static double baseGridInterval = 1000;

        public static float scale = 0.1f; //1mm is 0.1px.
        public static float centerX, centerY; // in mm.
        public static float mouseX, mouseY; // in mm.

        Font font = new Font("Verdana", 9);
        private void DrawGrids(Graphics e)
        {
            int ii = 0;

            double intervalX = 1000, intervalY = 1000; // mm
            double facX = 1, facY = 1;

            while ((intervalX * facX * scale) < 50)
                facX *= 5;
            while ((intervalY * facY * scale) < 50)
                facY *= 5;
            intervalX *= facX;
            intervalY *= facY;

            e.DrawLine(Pens.DarkBlue, mapBox.Width / 2, 0, mapBox.Width / 2, mapBox.Height);
            e.DrawLine(Pens.DarkBlue, 0, mapBox.Height / 2, mapBox.Width, mapBox.Height / 2);

            while (true)
            {
                var xxx = Math.Floor(((-mapBox.Width / 2) / scale + centerX) / intervalX + ii);
                int xx = (int)((xxx * intervalX - centerX) * scale) + mapBox.Width / 2;
                if (xx > mapBox.Width) break;
                e.DrawLine(Pens.BlueViolet, xx, 0, xx, mapBox.Height);
                e.DrawString($"{xxx * facX}m", font, Brushes.BlueViolet, xx, mapBox.Height - 18);
                ++ii;
            }
            ii = 0;
            while (true)
            {
                var yyy = Math.Floor(((mapBox.Height / 2) / scale + centerY) / intervalY - ii);
                int yy = -(int)((yyy * intervalY - centerY) * scale) + mapBox.Height / 2;
                if (yy > mapBox.Height) break;
                var unit = e.PageUnit;
                e.DrawLine(Pens.BlueViolet, 0, yy, mapBox.Width, yy);
                var box = e.MeasureString($"{yyy * facY}m", font);
                e.DrawString($"{yyy * facY}m", font, Brushes.BlueViolet, mapBox.Width - box.Width, yy);
                ++ii;
            }
        }
    }
}