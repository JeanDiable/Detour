﻿
namespace DViz
{
    partial class DViz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DViz));
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.materialButton7 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton6 = new MaterialSkin.Controls.MaterialButton();
            this.materialRadioButton3 = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialButton5 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton12 = new MaterialSkin.Controls.MaterialButton();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialRadioButton1 = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialTextBox21 = new MaterialSkin.Controls.MaterialTextBox2();
            this.materialRadioButton2 = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialButton4 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton3 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton1 = new MaterialSkin.Controls.MaterialButton();
            this.DragPosition = new MaterialSkin.Controls.MaterialButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.materialSwitch1 = new MaterialSkin.Controls.MaterialSwitch();
            this.materialComboBox1 = new MaterialSkin.Controls.MaterialComboBox();
            this.materialButton11 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton9 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton8 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton10 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton2 = new MaterialSkin.Controls.MaterialButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialSlider1 = new MaterialSkin.Controls.MaterialSlider();
            this.materialButton24 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton23 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton27 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton15 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton22 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton21 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton26 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton25 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton20 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton19 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton18 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton17 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton31 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton30 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton29 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton28 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton16 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton14 = new MaterialSkin.Controls.MaterialButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.mapBox = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.materialButton13 = new MaterialSkin.Controls.MaterialButton();
            this.materialButton32 = new MaterialSkin.Controls.MaterialButton();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.materialButton33 = new MaterialSkin.Controls.MaterialButton();
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mapBox)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Controls.Add(this.tabPage4);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.materialTabControl1.ImageList = this.imageList1;
            this.materialTabControl1.Location = new System.Drawing.Point(3, 64);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Multiline = true;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(285, 546);
            this.materialTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.materialButton7);
            this.tabPage1.Controls.Add(this.materialButton6);
            this.tabPage1.Controls.Add(this.materialRadioButton3);
            this.tabPage1.Controls.Add(this.materialButton5);
            this.tabPage1.Controls.Add(this.materialButton12);
            this.tabPage1.Controls.Add(this.materialLabel3);
            this.tabPage1.Controls.Add(this.materialLabel1);
            this.tabPage1.Controls.Add(this.materialRadioButton1);
            this.tabPage1.Controls.Add(this.materialTextBox21);
            this.tabPage1.Controls.Add(this.materialRadioButton2);
            this.tabPage1.Controls.Add(this.materialButton4);
            this.tabPage1.Controls.Add(this.materialButton3);
            this.tabPage1.Controls.Add(this.materialButton1);
            this.tabPage1.Controls.Add(this.DragPosition);
            this.tabPage1.ImageKey = "round_assessment_white_24dp.png";
            this.tabPage1.Location = new System.Drawing.Point(4, 58);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(277, 484);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "主界面";
            // 
            // materialButton7
            // 
            this.materialButton7.AutoSize = false;
            this.materialButton7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton7.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton7.Depth = 0;
            this.materialButton7.DrawShadows = false;
            this.materialButton7.Enabled = false;
            this.materialButton7.HighEmphasis = false;
            this.materialButton7.Icon = null;
            this.materialButton7.Location = new System.Drawing.Point(142, 186);
            this.materialButton7.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton7.Name = "materialButton7";
            this.materialButton7.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton7.Size = new System.Drawing.Size(127, 36);
            this.materialButton7.TabIndex = 9;
            this.materialButton7.Text = "查看状态记录";
            this.materialButton7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.materialButton7.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton7.UseAccentColor = false;
            this.materialButton7.UseVisualStyleBackColor = true;
            // 
            // materialButton6
            // 
            this.materialButton6.AutoSize = false;
            this.materialButton6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton6.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton6.Depth = 0;
            this.materialButton6.DrawShadows = false;
            this.materialButton6.HighEmphasis = false;
            this.materialButton6.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton6.Icon")));
            this.materialButton6.Location = new System.Drawing.Point(7, 186);
            this.materialButton6.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton6.Name = "materialButton6";
            this.materialButton6.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton6.Size = new System.Drawing.Size(131, 36);
            this.materialButton6.TabIndex = 9;
            this.materialButton6.Text = "尚未连接";
            this.materialButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.materialButton6.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Text;
            this.materialButton6.UseAccentColor = false;
            this.materialButton6.UseVisualStyleBackColor = true;
            // 
            // materialRadioButton3
            // 
            this.materialRadioButton3.AutoSize = true;
            this.materialRadioButton3.Checked = true;
            this.materialRadioButton3.Depth = 0;
            this.materialRadioButton3.Enabled = false;
            this.materialRadioButton3.Location = new System.Drawing.Point(102, 369);
            this.materialRadioButton3.Margin = new System.Windows.Forms.Padding(0);
            this.materialRadioButton3.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialRadioButton3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRadioButton3.Name = "materialRadioButton3";
            this.materialRadioButton3.Ripple = true;
            this.materialRadioButton3.Size = new System.Drawing.Size(161, 37);
            this.materialRadioButton3.TabIndex = 0;
            this.materialRadioButton3.TabStop = true;
            this.materialRadioButton3.Text = "建图且自动闭环模式";
            this.materialRadioButton3.UseVisualStyleBackColor = true;
            // 
            // materialButton5
            // 
            this.materialButton5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialButton5.AutoSize = false;
            this.materialButton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton5.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton5.Depth = 0;
            this.materialButton5.DrawShadows = false;
            this.materialButton5.HighEmphasis = false;
            this.materialButton5.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton5.Icon")));
            this.materialButton5.Location = new System.Drawing.Point(7, 142);
            this.materialButton5.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton5.Name = "materialButton5";
            this.materialButton5.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton5.Size = new System.Drawing.Size(261, 36);
            this.materialButton5.TabIndex = 9;
            this.materialButton5.Text = "x:0,y:0,th:0";
            this.materialButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.materialButton5.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Text;
            this.materialButton5.UseAccentColor = false;
            this.materialButton5.UseVisualStyleBackColor = true;
            // 
            // materialButton12
            // 
            this.materialButton12.AutoSize = false;
            this.materialButton12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton12.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton12.Depth = 0;
            this.materialButton12.Enabled = false;
            this.materialButton12.HighEmphasis = true;
            this.materialButton12.Icon = null;
            this.materialButton12.Location = new System.Drawing.Point(6, 412);
            this.materialButton12.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton12.Name = "materialButton12";
            this.materialButton12.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton12.Size = new System.Drawing.Size(264, 36);
            this.materialButton12.TabIndex = 2;
            this.materialButton12.Text = "下载地图";
            this.materialButton12.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton12.UseAccentColor = false;
            this.materialButton12.UseVisualStyleBackColor = true;
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel3.Location = new System.Drawing.Point(13, 321);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(85, 19);
            this.materialLabel3.TabIndex = 8;
            this.materialLabel3.Text = "算法运行模式";
            // 
            // materialLabel1
            // 
            this.materialLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel1.Location = new System.Drawing.Point(138, 108);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(127, 19);
            this.materialLabel1.TabIndex = 8;
            this.materialLabel1.Text = "尚未连接到算法内核";
            // 
            // materialRadioButton1
            // 
            this.materialRadioButton1.AutoSize = true;
            this.materialRadioButton1.Depth = 0;
            this.materialRadioButton1.Enabled = false;
            this.materialRadioButton1.Location = new System.Drawing.Point(0, 340);
            this.materialRadioButton1.Margin = new System.Windows.Forms.Padding(0);
            this.materialRadioButton1.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialRadioButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRadioButton1.Name = "materialRadioButton1";
            this.materialRadioButton1.Ripple = true;
            this.materialRadioButton1.Size = new System.Drawing.Size(119, 37);
            this.materialRadioButton1.TabIndex = 0;
            this.materialRadioButton1.TabStop = true;
            this.materialRadioButton1.Text = "锁定地图模式";
            this.materialRadioButton1.UseVisualStyleBackColor = true;
            // 
            // materialTextBox21
            // 
            this.materialTextBox21.AnimateReadOnly = false;
            this.materialTextBox21.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.materialTextBox21.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.materialTextBox21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.materialTextBox21.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.materialTextBox21.Depth = 0;
            this.materialTextBox21.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.materialTextBox21.HideSelection = true;
            this.materialTextBox21.Hint = "算法IP地址";
            this.materialTextBox21.LeadingIcon = null;
            this.materialTextBox21.Location = new System.Drawing.Point(6, 7);
            this.materialTextBox21.MaxLength = 32767;
            this.materialTextBox21.MouseState = MaterialSkin.MouseState.OUT;
            this.materialTextBox21.Name = "materialTextBox21";
            this.materialTextBox21.PasswordChar = '\0';
            this.materialTextBox21.PrefixSuffixText = null;
            this.materialTextBox21.ReadOnly = false;
            this.materialTextBox21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.materialTextBox21.SelectedText = "";
            this.materialTextBox21.SelectionLength = 0;
            this.materialTextBox21.SelectionStart = 0;
            this.materialTextBox21.ShortcutsEnabled = true;
            this.materialTextBox21.Size = new System.Drawing.Size(263, 48);
            this.materialTextBox21.TabIndex = 7;
            this.materialTextBox21.TabStop = false;
            this.materialTextBox21.Text = "192.168.1.8";
            this.materialTextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.materialTextBox21.TrailingIcon = null;
            this.materialTextBox21.UseSystemPasswordChar = false;
            // 
            // materialRadioButton2
            // 
            this.materialRadioButton2.AutoSize = true;
            this.materialRadioButton2.Depth = 0;
            this.materialRadioButton2.Enabled = false;
            this.materialRadioButton2.Location = new System.Drawing.Point(0, 369);
            this.materialRadioButton2.Margin = new System.Windows.Forms.Padding(0);
            this.materialRadioButton2.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialRadioButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRadioButton2.Name = "materialRadioButton2";
            this.materialRadioButton2.Ripple = true;
            this.materialRadioButton2.Size = new System.Drawing.Size(91, 37);
            this.materialRadioButton2.TabIndex = 0;
            this.materialRadioButton2.TabStop = true;
            this.materialRadioButton2.Text = "建图模式";
            this.materialRadioButton2.UseVisualStyleBackColor = true;
            // 
            // materialButton4
            // 
            this.materialButton4.AutoSize = false;
            this.materialButton4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton4.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton4.Depth = 0;
            this.materialButton4.HighEmphasis = true;
            this.materialButton4.Icon = null;
            this.materialButton4.Location = new System.Drawing.Point(83, 63);
            this.materialButton4.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton4.Name = "materialButton4";
            this.materialButton4.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton4.Size = new System.Drawing.Size(101, 36);
            this.materialButton4.TabIndex = 5;
            this.materialButton4.Text = "自动搜索IP";
            this.materialButton4.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton4.UseAccentColor = false;
            this.materialButton4.UseVisualStyleBackColor = true;
            // 
            // materialButton3
            // 
            this.materialButton3.AutoSize = false;
            this.materialButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton3.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton3.Depth = 0;
            this.materialButton3.DrawShadows = false;
            this.materialButton3.HighEmphasis = true;
            this.materialButton3.Icon = null;
            this.materialButton3.Location = new System.Drawing.Point(192, 63);
            this.materialButton3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton3.Name = "materialButton3";
            this.materialButton3.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton3.Size = new System.Drawing.Size(77, 36);
            this.materialButton3.TabIndex = 6;
            this.materialButton3.Text = "连接";
            this.materialButton3.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton3.UseAccentColor = false;
            this.materialButton3.UseVisualStyleBackColor = true;
            // 
            // materialButton1
            // 
            this.materialButton1.AutoSize = false;
            this.materialButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton1.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton1.Depth = 0;
            this.materialButton1.Enabled = false;
            this.materialButton1.HighEmphasis = true;
            this.materialButton1.Icon = null;
            this.materialButton1.Location = new System.Drawing.Point(6, 274);
            this.materialButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton1.Name = "materialButton1";
            this.materialButton1.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton1.Size = new System.Drawing.Size(263, 36);
            this.materialButton1.TabIndex = 0;
            this.materialButton1.Text = "手动输入位置";
            this.materialButton1.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton1.UseAccentColor = false;
            this.materialButton1.UseVisualStyleBackColor = true;
            // 
            // DragPosition
            // 
            this.DragPosition.AutoSize = false;
            this.DragPosition.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.DragPosition.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.DragPosition.Depth = 0;
            this.DragPosition.Enabled = false;
            this.DragPosition.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DragPosition.HighEmphasis = true;
            this.DragPosition.Icon = null;
            this.DragPosition.Location = new System.Drawing.Point(6, 230);
            this.DragPosition.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.DragPosition.MouseState = MaterialSkin.MouseState.HOVER;
            this.DragPosition.Name = "DragPosition";
            this.DragPosition.NoAccentTextColor = System.Drawing.Color.Empty;
            this.DragPosition.Size = new System.Drawing.Size(263, 36);
            this.DragPosition.TabIndex = 0;
            this.DragPosition.Text = "图上拖拽设定位置";
            this.DragPosition.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.DragPosition.UseAccentColor = true;
            this.DragPosition.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.materialSwitch1);
            this.tabPage2.Controls.Add(this.materialComboBox1);
            this.tabPage2.Controls.Add(this.materialButton11);
            this.tabPage2.Controls.Add(this.materialButton9);
            this.tabPage2.Controls.Add(this.materialButton32);
            this.tabPage2.Controls.Add(this.materialButton8);
            this.tabPage2.Controls.Add(this.materialButton10);
            this.tabPage2.Controls.Add(this.materialButton2);
            this.tabPage2.ImageKey = "round_build_white_24dp.png";
            this.tabPage2.Location = new System.Drawing.Point(4, 58);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(277, 484);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "设置";
            // 
            // materialSwitch1
            // 
            this.materialSwitch1.AutoSize = true;
            this.materialSwitch1.Depth = 0;
            this.materialSwitch1.Location = new System.Drawing.Point(6, 250);
            this.materialSwitch1.Margin = new System.Windows.Forms.Padding(0);
            this.materialSwitch1.MouseLocation = new System.Drawing.Point(-1, -1);
            this.materialSwitch1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSwitch1.Name = "materialSwitch1";
            this.materialSwitch1.Ripple = true;
            this.materialSwitch1.Size = new System.Drawing.Size(170, 37);
            this.materialSwitch1.TabIndex = 4;
            this.materialSwitch1.Text = "自动记录导航位置";
            this.materialSwitch1.UseVisualStyleBackColor = true;
            // 
            // materialComboBox1
            // 
            this.materialComboBox1.AutoResize = false;
            this.materialComboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialComboBox1.Depth = 0;
            this.materialComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.materialComboBox1.DropDownHeight = 174;
            this.materialComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.materialComboBox1.DropDownWidth = 121;
            this.materialComboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.materialComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialComboBox1.FormattingEnabled = true;
            this.materialComboBox1.Hint = "雷达型号";
            this.materialComboBox1.IntegralHeight = false;
            this.materialComboBox1.ItemHeight = 43;
            this.materialComboBox1.Items.AddRange(new object[] {
            "自定义雷达"});
            this.materialComboBox1.Location = new System.Drawing.Point(6, 6);
            this.materialComboBox1.MaxDropDownItems = 4;
            this.materialComboBox1.MouseState = MaterialSkin.MouseState.OUT;
            this.materialComboBox1.Name = "materialComboBox1";
            this.materialComboBox1.Size = new System.Drawing.Size(263, 49);
            this.materialComboBox1.StartIndex = 0;
            this.materialComboBox1.TabIndex = 3;
            // 
            // materialButton11
            // 
            this.materialButton11.AutoSize = false;
            this.materialButton11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton11.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.materialButton11.Depth = 0;
            this.materialButton11.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.materialButton11.HighEmphasis = true;
            this.materialButton11.Icon = null;
            this.materialButton11.Location = new System.Drawing.Point(6, 208);
            this.materialButton11.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton11.Name = "materialButton11";
            this.materialButton11.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton11.Size = new System.Drawing.Size(263, 36);
            this.materialButton11.TabIndex = 1;
            this.materialButton11.Text = "绘制车体轮廓";
            this.materialButton11.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton11.UseAccentColor = false;
            this.materialButton11.UseVisualStyleBackColor = true;
            // 
            // materialButton9
            // 
            this.materialButton9.AutoSize = false;
            this.materialButton9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton9.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.materialButton9.Depth = 0;
            this.materialButton9.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.materialButton9.HighEmphasis = true;
            this.materialButton9.Icon = null;
            this.materialButton9.Location = new System.Drawing.Point(6, 160);
            this.materialButton9.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton9.Name = "materialButton9";
            this.materialButton9.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton9.Size = new System.Drawing.Size(263, 36);
            this.materialButton9.TabIndex = 1;
            this.materialButton9.Text = "调节导航参数";
            this.materialButton9.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton9.UseAccentColor = false;
            this.materialButton9.UseVisualStyleBackColor = true;
            // 
            // materialButton8
            // 
            this.materialButton8.AutoSize = false;
            this.materialButton8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton8.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.materialButton8.Depth = 0;
            this.materialButton8.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.materialButton8.HighEmphasis = true;
            this.materialButton8.Icon = null;
            this.materialButton8.Location = new System.Drawing.Point(7, 64);
            this.materialButton8.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton8.Name = "materialButton8";
            this.materialButton8.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton8.Size = new System.Drawing.Size(157, 36);
            this.materialButton8.TabIndex = 1;
            this.materialButton8.Text = "下载自定义雷达插件";
            this.materialButton8.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Text;
            this.materialButton8.UseAccentColor = true;
            this.materialButton8.UseVisualStyleBackColor = true;
            this.materialButton8.Visible = false;
            // 
            // materialButton10
            // 
            this.materialButton10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.materialButton10.AutoSize = false;
            this.materialButton10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton10.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.materialButton10.Depth = 0;
            this.materialButton10.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.materialButton10.HighEmphasis = true;
            this.materialButton10.Icon = null;
            this.materialButton10.Location = new System.Drawing.Point(4, 400);
            this.materialButton10.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton10.Name = "materialButton10";
            this.materialButton10.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton10.Size = new System.Drawing.Size(265, 36);
            this.materialButton10.TabIndex = 1;
            this.materialButton10.Text = "重启算法";
            this.materialButton10.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton10.UseAccentColor = true;
            this.materialButton10.UseVisualStyleBackColor = true;
            // 
            // materialButton2
            // 
            this.materialButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.materialButton2.AutoSize = false;
            this.materialButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton2.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.materialButton2.Depth = 0;
            this.materialButton2.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.materialButton2.HighEmphasis = true;
            this.materialButton2.Icon = null;
            this.materialButton2.Location = new System.Drawing.Point(4, 442);
            this.materialButton2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton2.Name = "materialButton2";
            this.materialButton2.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton2.Size = new System.Drawing.Size(265, 36);
            this.materialButton2.TabIndex = 1;
            this.materialButton2.Text = "清空配置并重启算法";
            this.materialButton2.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton2.UseAccentColor = true;
            this.materialButton2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.materialButton13);
            this.tabPage3.Controls.Add(this.materialLabel4);
            this.tabPage3.Controls.Add(this.materialLabel2);
            this.tabPage3.Controls.Add(this.materialSlider1);
            this.tabPage3.Controls.Add(this.materialButton24);
            this.tabPage3.Controls.Add(this.materialButton23);
            this.tabPage3.Controls.Add(this.materialButton27);
            this.tabPage3.Controls.Add(this.materialButton15);
            this.tabPage3.Controls.Add(this.materialButton22);
            this.tabPage3.Controls.Add(this.materialButton21);
            this.tabPage3.Controls.Add(this.materialButton26);
            this.tabPage3.Controls.Add(this.materialButton25);
            this.tabPage3.Controls.Add(this.materialButton20);
            this.tabPage3.Controls.Add(this.materialButton19);
            this.tabPage3.Controls.Add(this.materialButton18);
            this.tabPage3.Controls.Add(this.materialButton17);
            this.tabPage3.Controls.Add(this.materialButton31);
            this.tabPage3.Controls.Add(this.materialButton30);
            this.tabPage3.Controls.Add(this.materialButton29);
            this.tabPage3.Controls.Add(this.materialButton28);
            this.tabPage3.Controls.Add(this.materialButton16);
            this.tabPage3.Controls.Add(this.materialButton14);
            this.tabPage3.ImageKey = "map-solid.png";
            this.tabPage3.Location = new System.Drawing.Point(4, 58);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(277, 484);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "地图";
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel4.Location = new System.Drawing.Point(9, 10);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(71, 19);
            this.materialLabel4.TabIndex = 4;
            this.materialLabel4.Text = "关键帧编辑";
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.materialLabel2.Location = new System.Drawing.Point(10, 256);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(57, 19);
            this.materialLabel2.TabIndex = 4;
            this.materialLabel2.Text = "点云编辑";
            // 
            // materialSlider1
            // 
            this.materialSlider1.Depth = 0;
            this.materialSlider1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialSlider1.Location = new System.Drawing.Point(11, 277);
            this.materialSlider1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialSlider1.Name = "materialSlider1";
            this.materialSlider1.RangeMin = 10;
            this.materialSlider1.Size = new System.Drawing.Size(247, 40);
            this.materialSlider1.TabIndex = 3;
            this.materialSlider1.Text = "半径";
            this.materialSlider1.Value = 10;
            this.materialSlider1.ValueSuffix = "px";
            // 
            // materialButton24
            // 
            this.materialButton24.AutoSize = false;
            this.materialButton24.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton24.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton24.Depth = 0;
            this.materialButton24.HighEmphasis = true;
            this.materialButton24.Icon = null;
            this.materialButton24.Location = new System.Drawing.Point(100, 36);
            this.materialButton24.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton24.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton24.Name = "materialButton24";
            this.materialButton24.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton24.Size = new System.Drawing.Size(170, 36);
            this.materialButton24.TabIndex = 2;
            this.materialButton24.Text = "指定平移旋转数值";
            this.materialButton24.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton24.UseAccentColor = false;
            this.materialButton24.UseVisualStyleBackColor = true;
            // 
            // materialButton23
            // 
            this.materialButton23.AutoSize = false;
            this.materialButton23.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton23.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton23.Depth = 0;
            this.materialButton23.HighEmphasis = true;
            this.materialButton23.Icon = null;
            this.materialButton23.Location = new System.Drawing.Point(100, 80);
            this.materialButton23.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton23.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton23.Name = "materialButton23";
            this.materialButton23.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton23.Size = new System.Drawing.Size(170, 36);
            this.materialButton23.TabIndex = 2;
            this.materialButton23.Text = "分别旋转";
            this.materialButton23.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton23.UseAccentColor = false;
            this.materialButton23.UseVisualStyleBackColor = true;
            // 
            // materialButton27
            // 
            this.materialButton27.AutoSize = false;
            this.materialButton27.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton27.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton27.Depth = 0;
            this.materialButton27.HighEmphasis = true;
            this.materialButton27.Icon = null;
            this.materialButton27.Location = new System.Drawing.Point(75, 212);
            this.materialButton27.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton27.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton27.Name = "materialButton27";
            this.materialButton27.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton27.Size = new System.Drawing.Size(195, 36);
            this.materialButton27.TabIndex = 2;
            this.materialButton27.Text = "解除和未选定部分的关联";
            this.materialButton27.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton27.UseAccentColor = false;
            this.materialButton27.UseVisualStyleBackColor = true;
            // 
            // materialButton15
            // 
            this.materialButton15.AutoSize = false;
            this.materialButton15.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton15.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton15.Depth = 0;
            this.materialButton15.HighEmphasis = true;
            this.materialButton15.Icon = null;
            this.materialButton15.Location = new System.Drawing.Point(6, 422);
            this.materialButton15.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton15.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton15.Name = "materialButton15";
            this.materialButton15.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton15.Size = new System.Drawing.Size(125, 36);
            this.materialButton15.TabIndex = 2;
            this.materialButton15.Text = "加载本机的地图";
            this.materialButton15.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton15.UseAccentColor = false;
            this.materialButton15.UseVisualStyleBackColor = true;
            // 
            // materialButton22
            // 
            this.materialButton22.AutoSize = false;
            this.materialButton22.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton22.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton22.Depth = 0;
            this.materialButton22.HighEmphasis = true;
            this.materialButton22.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton22.Icon")));
            this.materialButton22.Location = new System.Drawing.Point(195, 124);
            this.materialButton22.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton22.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton22.Name = "materialButton22";
            this.materialButton22.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton22.Size = new System.Drawing.Size(42, 36);
            this.materialButton22.TabIndex = 2;
            this.materialButton22.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton22.UseAccentColor = false;
            this.materialButton22.UseVisualStyleBackColor = true;
            // 
            // materialButton21
            // 
            this.materialButton21.AutoSize = false;
            this.materialButton21.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton21.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton21.Depth = 0;
            this.materialButton21.HighEmphasis = true;
            this.materialButton21.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton21.Icon")));
            this.materialButton21.Location = new System.Drawing.Point(100, 124);
            this.materialButton21.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton21.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton21.Name = "materialButton21";
            this.materialButton21.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton21.Size = new System.Drawing.Size(86, 36);
            this.materialButton21.TabIndex = 2;
            this.materialButton21.Text = "锁定";
            this.materialButton21.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton21.UseAccentColor = false;
            this.materialButton21.UseVisualStyleBackColor = true;
            // 
            // materialButton26
            // 
            this.materialButton26.AutoSize = false;
            this.materialButton26.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton26.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton26.Depth = 0;
            this.materialButton26.HighEmphasis = true;
            this.materialButton26.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton26.Icon")));
            this.materialButton26.Location = new System.Drawing.Point(100, 168);
            this.materialButton26.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton26.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton26.Name = "materialButton26";
            this.materialButton26.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton26.Size = new System.Drawing.Size(170, 36);
            this.materialButton26.TabIndex = 2;
            this.materialButton26.Text = "解除关联";
            this.materialButton26.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton26.UseAccentColor = false;
            this.materialButton26.UseVisualStyleBackColor = true;
            // 
            // materialButton25
            // 
            this.materialButton25.AutoSize = false;
            this.materialButton25.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton25.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton25.Depth = 0;
            this.materialButton25.HighEmphasis = true;
            this.materialButton25.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton25.Icon")));
            this.materialButton25.Location = new System.Drawing.Point(6, 168);
            this.materialButton25.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton25.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton25.Name = "materialButton25";
            this.materialButton25.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton25.Size = new System.Drawing.Size(86, 36);
            this.materialButton25.TabIndex = 2;
            this.materialButton25.Text = "关联";
            this.materialButton25.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton25.UseAccentColor = false;
            this.materialButton25.UseVisualStyleBackColor = true;
            // 
            // materialButton20
            // 
            this.materialButton20.AutoSize = false;
            this.materialButton20.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton20.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton20.Depth = 0;
            this.materialButton20.HighEmphasis = true;
            this.materialButton20.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton20.Icon")));
            this.materialButton20.Location = new System.Drawing.Point(6, 124);
            this.materialButton20.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton20.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton20.Name = "materialButton20";
            this.materialButton20.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton20.Size = new System.Drawing.Size(86, 36);
            this.materialButton20.TabIndex = 2;
            this.materialButton20.Text = "删除";
            this.materialButton20.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton20.UseAccentColor = false;
            this.materialButton20.UseVisualStyleBackColor = true;
            // 
            // materialButton19
            // 
            this.materialButton19.AutoSize = false;
            this.materialButton19.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton19.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton19.Depth = 0;
            this.materialButton19.HighEmphasis = true;
            this.materialButton19.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton19.Icon")));
            this.materialButton19.Location = new System.Drawing.Point(6, 80);
            this.materialButton19.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton19.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton19.Name = "materialButton19";
            this.materialButton19.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton19.Size = new System.Drawing.Size(86, 36);
            this.materialButton19.TabIndex = 2;
            this.materialButton19.Text = "旋转";
            this.materialButton19.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton19.UseAccentColor = false;
            this.materialButton19.UseVisualStyleBackColor = true;
            // 
            // materialButton18
            // 
            this.materialButton18.AutoSize = false;
            this.materialButton18.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton18.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton18.Depth = 0;
            this.materialButton18.HighEmphasis = true;
            this.materialButton18.Icon = ((System.Drawing.Image)(resources.GetObject("materialButton18.Icon")));
            this.materialButton18.Location = new System.Drawing.Point(6, 36);
            this.materialButton18.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton18.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton18.Name = "materialButton18";
            this.materialButton18.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton18.Size = new System.Drawing.Size(86, 36);
            this.materialButton18.TabIndex = 2;
            this.materialButton18.Text = "平移";
            this.materialButton18.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton18.UseAccentColor = false;
            this.materialButton18.UseVisualStyleBackColor = true;
            // 
            // materialButton17
            // 
            this.materialButton17.AutoSize = false;
            this.materialButton17.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton17.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton17.Depth = 0;
            this.materialButton17.HighEmphasis = true;
            this.materialButton17.Icon = null;
            this.materialButton17.Location = new System.Drawing.Point(100, 465);
            this.materialButton17.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton17.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton17.Name = "materialButton17";
            this.materialButton17.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton17.Size = new System.Drawing.Size(65, 36);
            this.materialButton17.TabIndex = 2;
            this.materialButton17.Text = "清空";
            this.materialButton17.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton17.UseAccentColor = false;
            this.materialButton17.UseVisualStyleBackColor = true;
            // 
            // materialButton31
            // 
            this.materialButton31.AutoSize = false;
            this.materialButton31.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton31.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton31.Depth = 0;
            this.materialButton31.HighEmphasis = true;
            this.materialButton31.Icon = null;
            this.materialButton31.Location = new System.Drawing.Point(159, 360);
            this.materialButton31.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton31.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton31.Name = "materialButton31";
            this.materialButton31.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton31.Size = new System.Drawing.Size(111, 36);
            this.materialButton31.TabIndex = 2;
            this.materialButton31.Text = "擦除区域";
            this.materialButton31.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton31.UseAccentColor = false;
            this.materialButton31.UseVisualStyleBackColor = true;
            // 
            // materialButton30
            // 
            this.materialButton30.AutoSize = false;
            this.materialButton30.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton30.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton30.Depth = 0;
            this.materialButton30.HighEmphasis = true;
            this.materialButton30.Icon = null;
            this.materialButton30.Location = new System.Drawing.Point(6, 360);
            this.materialButton30.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton30.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton30.Name = "materialButton30";
            this.materialButton30.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton30.Size = new System.Drawing.Size(145, 36);
            this.materialButton30.TabIndex = 2;
            this.materialButton30.Text = "绘制环境变化区域";
            this.materialButton30.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton30.UseAccentColor = false;
            this.materialButton30.UseVisualStyleBackColor = true;
            // 
            // materialButton29
            // 
            this.materialButton29.AutoSize = false;
            this.materialButton29.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton29.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton29.Depth = 0;
            this.materialButton29.HighEmphasis = true;
            this.materialButton29.Icon = null;
            this.materialButton29.Location = new System.Drawing.Point(100, 317);
            this.materialButton29.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton29.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton29.Name = "materialButton29";
            this.materialButton29.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton29.Size = new System.Drawing.Size(170, 36);
            this.materialButton29.TabIndex = 2;
            this.materialButton29.Text = "绘制行人行车区域";
            this.materialButton29.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton29.UseAccentColor = false;
            this.materialButton29.UseVisualStyleBackColor = true;
            // 
            // materialButton28
            // 
            this.materialButton28.AutoSize = false;
            this.materialButton28.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton28.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton28.Depth = 0;
            this.materialButton28.HighEmphasis = true;
            this.materialButton28.Icon = null;
            this.materialButton28.Location = new System.Drawing.Point(6, 317);
            this.materialButton28.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton28.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton28.Name = "materialButton28";
            this.materialButton28.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton28.Size = new System.Drawing.Size(86, 36);
            this.materialButton28.TabIndex = 2;
            this.materialButton28.Text = "擦除点云";
            this.materialButton28.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton28.UseAccentColor = false;
            this.materialButton28.UseVisualStyleBackColor = true;
            // 
            // materialButton16
            // 
            this.materialButton16.AutoSize = false;
            this.materialButton16.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton16.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton16.Depth = 0;
            this.materialButton16.HighEmphasis = true;
            this.materialButton16.Icon = null;
            this.materialButton16.Location = new System.Drawing.Point(8, 465);
            this.materialButton16.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton16.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton16.Name = "materialButton16";
            this.materialButton16.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton16.Size = new System.Drawing.Size(84, 36);
            this.materialButton16.TabIndex = 2;
            this.materialButton16.Text = "合并地图";
            this.materialButton16.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton16.UseAccentColor = false;
            this.materialButton16.UseVisualStyleBackColor = true;
            // 
            // materialButton14
            // 
            this.materialButton14.AutoSize = false;
            this.materialButton14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton14.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton14.Depth = 0;
            this.materialButton14.HighEmphasis = true;
            this.materialButton14.Icon = null;
            this.materialButton14.Location = new System.Drawing.Point(139, 422);
            this.materialButton14.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton14.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton14.Name = "materialButton14";
            this.materialButton14.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton14.Size = new System.Drawing.Size(131, 36);
            this.materialButton14.TabIndex = 2;
            this.materialButton14.Text = "保存地图到本机";
            this.materialButton14.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton14.UseAccentColor = false;
            this.materialButton14.UseVisualStyleBackColor = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "round_assessment_white_24dp.png");
            this.imageList1.Images.SetKeyName(1, "round_build_white_24dp.png");
            this.imageList1.Images.SetKeyName(2, "map-solid.png");
            this.imageList1.Images.SetKeyName(3, "round_gps_fixed_white_24dp.png");
            this.imageList1.Images.SetKeyName(4, "toolbox-solid.png");
            // 
            // mapBox
            // 
            this.mapBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mapBox.BackColor = System.Drawing.Color.Black;
            this.mapBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mapBox.Location = new System.Drawing.Point(281, 68);
            this.mapBox.Name = "mapBox";
            this.mapBox.Size = new System.Drawing.Size(586, 539);
            this.mapBox.TabIndex = 1;
            this.mapBox.TabStop = false;
            this.mapBox.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 40;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // materialButton13
            // 
            this.materialButton13.AutoSize = false;
            this.materialButton13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton13.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton13.Depth = 0;
            this.materialButton13.HighEmphasis = true;
            this.materialButton13.Icon = null;
            this.materialButton13.Location = new System.Drawing.Point(173, 465);
            this.materialButton13.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton13.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton13.Name = "materialButton13";
            this.materialButton13.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton13.Size = new System.Drawing.Size(97, 36);
            this.materialButton13.TabIndex = 5;
            this.materialButton13.Text = "上传至算法";
            this.materialButton13.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton13.UseAccentColor = true;
            this.materialButton13.UseVisualStyleBackColor = true;
            // 
            // materialButton32
            // 
            this.materialButton32.AutoSize = false;
            this.materialButton32.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton32.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Dense;
            this.materialButton32.Depth = 0;
            this.materialButton32.Font = new System.Drawing.Font("隶书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.materialButton32.HighEmphasis = true;
            this.materialButton32.Icon = null;
            this.materialButton32.Location = new System.Drawing.Point(172, 64);
            this.materialButton32.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton32.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton32.Name = "materialButton32";
            this.materialButton32.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton32.Size = new System.Drawing.Size(97, 36);
            this.materialButton32.TabIndex = 1;
            this.materialButton32.Text = "配置雷达";
            this.materialButton32.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            this.materialButton32.UseAccentColor = true;
            this.materialButton32.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.materialButton33);
            this.tabPage4.ImageKey = "toolbox-solid.png";
            this.tabPage4.Location = new System.Drawing.Point(4, 58);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(277, 484);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "其它";
            // 
            // materialButton33
            // 
            this.materialButton33.AutoSize = false;
            this.materialButton33.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialButton33.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            this.materialButton33.Depth = 0;
            this.materialButton33.HighEmphasis = true;
            this.materialButton33.Icon = null;
            this.materialButton33.Location = new System.Drawing.Point(6, 8);
            this.materialButton33.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialButton33.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialButton33.Name = "materialButton33";
            this.materialButton33.NoAccentTextColor = System.Drawing.Color.Empty;
            this.materialButton33.Size = new System.Drawing.Size(264, 36);
            this.materialButton33.TabIndex = 3;
            this.materialButton33.Text = "自定义雷达调试";
            this.materialButton33.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Outlined;
            this.materialButton33.UseAccentColor = false;
            this.materialButton33.UseVisualStyleBackColor = true;
            // 
            // DViz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(873, 613);
            this.Controls.Add(this.mapBox);
            this.Controls.Add(this.materialTabControl1);
            this.DrawerShowIconsWhenHidden = true;
            this.DrawerTabControl = this.materialTabControl1;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "DViz";
            this.Text = "尚未连接到算法内核，等待连接";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DViz_FormClosing);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mapBox)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox mapBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage tabPage3;
        private MaterialSkin.Controls.MaterialButton DragPosition;
        private MaterialSkin.Controls.MaterialButton materialButton1;
        private MaterialSkin.Controls.MaterialButton materialButton2;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialTextBox2 materialTextBox21;
        private MaterialSkin.Controls.MaterialButton materialButton4;
        private MaterialSkin.Controls.MaterialButton materialButton3;
        private MaterialSkin.Controls.MaterialButton materialButton5;
        private MaterialSkin.Controls.MaterialButton materialButton6;
        private MaterialSkin.Controls.MaterialButton materialButton7;
        private MaterialSkin.Controls.MaterialButton materialButton8;
        private MaterialSkin.Controls.MaterialComboBox materialComboBox1;
        private MaterialSkin.Controls.MaterialSwitch materialSwitch1;
        private MaterialSkin.Controls.MaterialButton materialButton9;
        private MaterialSkin.Controls.MaterialButton materialButton10;
        private MaterialSkin.Controls.MaterialButton materialButton11;
        private MaterialSkin.Controls.MaterialButton materialButton15;
        private MaterialSkin.Controls.MaterialButton materialButton17;
        private MaterialSkin.Controls.MaterialButton materialButton16;
        private MaterialSkin.Controls.MaterialButton materialButton14;
        private MaterialSkin.Controls.MaterialRadioButton materialRadioButton1;
        private MaterialSkin.Controls.MaterialRadioButton materialRadioButton2;
        private MaterialSkin.Controls.MaterialRadioButton materialRadioButton3;
        private MaterialSkin.Controls.MaterialButton materialButton12;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialButton materialButton18;
        private MaterialSkin.Controls.MaterialButton materialButton24;
        private MaterialSkin.Controls.MaterialButton materialButton23;
        private MaterialSkin.Controls.MaterialButton materialButton27;
        private MaterialSkin.Controls.MaterialButton materialButton22;
        private MaterialSkin.Controls.MaterialButton materialButton21;
        private MaterialSkin.Controls.MaterialButton materialButton26;
        private MaterialSkin.Controls.MaterialButton materialButton25;
        private MaterialSkin.Controls.MaterialButton materialButton20;
        private MaterialSkin.Controls.MaterialButton materialButton19;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialSlider materialSlider1;
        private MaterialSkin.Controls.MaterialButton materialButton31;
        private MaterialSkin.Controls.MaterialButton materialButton30;
        private MaterialSkin.Controls.MaterialButton materialButton29;
        private MaterialSkin.Controls.MaterialButton materialButton28;
        private MaterialSkin.Controls.MaterialButton materialButton13;
        private MaterialSkin.Controls.MaterialButton materialButton32;
        private System.Windows.Forms.TabPage tabPage4;
        private MaterialSkin.Controls.MaterialButton materialButton33;
    }
}