﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DViz
{
    class SupportedLidars
    {
    }

    class HokuyoURGLidar
    {

    }

    class SickNanoLidar
    {

    }

    class SiminicsLidar
    {

    }

    class WLR716Lidar
    {

    }

    class PnFR2kLidar
    {

    }

    class CustomLidar
    {

    }
}
